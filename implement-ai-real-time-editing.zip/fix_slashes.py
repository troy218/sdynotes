import io

p = 'sdynotes/sdynotes.js'
lines = io.open(p, encoding='utf-8').read().split('\n')

# apply:(ops) 줄을 찾고, 그 뒤 첫 }catch(e){} 가 진짜 끝
mid = None
for i, l in enumerate(lines):
    if 'apply:(ops)=>{ try{ return aiEditApply(ops);' in l:
        mid = i
        break
assert mid is not None, 'apply line not found'
hi = None
for j in range(mid, mid + 20):
    if lines[j].strip() == '}catch(e){}':
        hi = j
        break
assert hi is not None

lo = 0
for i, l in enumerate(lines):
    if 'AI 패널이 노트 글을 꺼내 쓰는 다리.' in l:
        lo = i
        break

count = 0
for i in range(lo, hi + 1):
    before = lines[i]
    lines[i] = lines[i].replace(chr(92) * 2, chr(92))
    if lines[i] != before:
        count += 1

io.open(p, 'w', encoding='utf-8').write('\n'.join(lines))
print('slashes fixed:', lo + 1, '-', hi + 1, 'lines changed:', count)
