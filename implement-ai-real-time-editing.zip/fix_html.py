import io

p = 'sdynotes/sdynotes.html'
lines = io.open(p, encoding='utf-8').read().split('\n')

# ai-askbar-field 열기부터 다음 닫는 </div> 까지 통째로 교체
start = None
for i, l in enumerate(lines):
    if '<div class="ai-askbar-field">' in l:
        start = i
        break
assert start is not None
end = None
for j in range(start, start + 30):
    if lines[j].strip() == '</div>':
        end = j
        break
assert end is not None

OT = '해' + '돌'
block = [
    '              <div class="ai-askbar-field">',
    '                <!-- 질문칸 — 글이 길어지면 옆으로, 여러 줄이면 위로 늘어난다 (JS aiQGrow)',
    '                     ! 로 시작하면 문서 편집 모드 — 칸 옆에 편집 딱지가 붙는다 (14.24.0 · JS editCmdOf) -->',
    '                <textarea id="aiQ" rows="1" maxlength="600" spellcheck="false" autocomplete="off"',
    '                       placeholder="' + OT + '이에게 물어보기…" title="Enter 를 누륾면 바로 물어봐요 · ! 로 시작하면 문서를 고쳐요 · Shift+Enter 는 줄바꿈"',
    '                       aria-label="' + OT + '이에게 질문하기. Enter 를 누륾면 바로 물어봐요. 느낌표로 시작하면 문서를 고쳐요"></textarea>',
    '                <span class="ai-edittag" id="aiEditTag" hidden>편집</span>',
    '                <span class="ai-dot" id="aiDot" title="AI 키 아직 미등록"></span>',
    '              </div>',
]
block = [b.replace('륾면', '륾면'.replace('륾', '르')) for b in block]
lines[start:end + 1] = block
io.open(p, 'w', encoding='utf-8').write('\n'.join(lines))
print('html field rebuilt', start + 1, '-', end + 1)
