import io

p = 'sdynotes/sdynotes.js'
s = io.open(p, encoding='utf-8').read()

OTTER = '해' + '돌'      # 핵돌이 (이스케이프 오입 방지용 조립)
SKIP = '건' + '너뛴'
GIVE = '내' + '놓는'

def rep(old, new, n=1):
    global s
    c = s.count(old)
    assert c == n, ('count', c, old[:60])
    s = s.replace(old, new)

# 1) 종류 딱지에 '문서 편집' 추가
rep("var KIND={note:'노트 질문',free:'자유 질문',outlinePage:'이 페이지',outlineDoc:'전체 페이지'};",
    "var KIND={note:'노트 질문',free:'자유 질문',outlinePage:'이 페이지',outlineDoc:'전체 페이지',edit:'문서 편집'};")

# 2) parseChat 뒤에 편집 모듈 삽입
EDIT_MOD = r'''
  /* ── 14.24.0 · O 편집 — 검색창 접두사(!)로 문서를 직접 고친다 ────────────────
     흐름: !명령 → 문서 상태 스냅샷(다리 snapshot) + 요청을 서버 task=edit 로 →
     모델이 G '@' 명령 줄을 파서(sdyAiEditParse)가 뽑아 → 다리 apply 가
     문서에 곧바로 적용(되돌리기 한 덩어리) → 말풍선에는 @done 요약만 보여 준다. */
  var EDIT_PRE=/^\s*(?:[!！]+|\/(?:edit|수정|편집)(?=\s|$)|(?:수정|편집)\s*[:：])\s*/;
  function editCmdOf(q){
    if(!EDIT_PRE.test(q||'')) return null;
    return String(q).replace(EDIT_PRE,'').trim();
  }
  // 문서 상태 스냅샷 — 편집기 스코프의 다리가 만든다. 다리가 없는 오래된 페이지면 빈 문자열.
  function aiSnapshot(){
    try{
      if(window.__sdyAiBridge&&typeof window.__sdyAiBridge.snapshot==='function')
        return String(window.__sdyAiBridge.snapshot()||'');
    }catch(e){}
    return '';
  }
  /* 말하는 중 말풍선 — '@' 명령 줄은 아직 실행 전이라 보여 주지 않고
     지금까지 모인 명령 수만 세어 준다. */
  function editProgress(acc){
    var n=(String(acc||'').match(/^@/gm)||[]).length;
    return n?('문서 고칠 설계도를 그리는 중… · 명령 '+n+'개'):'노트를 살펴 보는 중…';
  }
  /* 답이 다 오면(done) — 파서가 '@' 줄을 실행 계획으로 바꾸고 다리 적용기가
     문서에 곧바로 반영한다. 스트림 중간에는 절대 부르지 않는다(부분 명령 적용 금지).
     말풍선에는 @done 요약 + 반영·K 수와 이유를 얹어 보여 준다. */
  function editApplyDone(full){
    var parsed=(window.sdyAiEditParse?window.sdyAiEditParse(full):{ops:[],say:'',dropped:0});
    var res=null;
    try{
      if(window.__sdyAiBridge&&typeof window.__sdyAiBridge.apply==='function')
        res=window.__sdyAiBridge.apply(parsed.ops);
    }catch(e){ res=null; }
    var applied=res?res.applied:0;
    var failed=(res?res.failed:((parsed.ops||[]).length||0))+(parsed.dropped||0);
    var say=parsed.say||(applied?'요청대로 문서를 고쳤어요 O~':'바꿀 명령을 찾지 못했어요');
    var line=[];
    if(applied>0) line.push('적용 '+applied+'개');
    if(failed>0) line.push('K 명령 '+failed+'개');
    var out2=say+(line.length?('\n\n'+line.join(' · ')):'');
    if(res&&res.notes&&res.notes.length) out2+='\n'+res.notes.join('\n');
    if(applied>0){
      try{ if(window.toast) window.toast('OO가 문서를 고쳤어요 · 되돌리기(Ctrl+Z)로 원래대로',2600); }catch(e){}
    }
    return out2;
  }
  /* 편집 명령 파서 — 모델이 G '@' 명령 줄만 뽑아 실행 계획으로 바꾼다.
     순수 함수라 계약 테스트(jsdom)에서 그대로 돌린다.
     · @mv id|x|y   @sz id|w|h   @bx id|x|y|w|h   @tx id|텍스트
     · @add 쪽|x|y|w|h|텍스트   @del id         @done 한 줄 요약
     · 못 알아듣는 @줄·서술 문장은 버리고(dropped), 코드블록 울타리·굵은 글씨 장식은 벗긴다 */
  window.sdyAiEditParse=function(raw){
    var ops=[], say='', dropped=0;
    var src=String(raw==null?'':raw).replace(/\r\n?/g,'\n');
    src=src.replace(/```[a-zA-Z]*\n?/g,'\n').replace(/\*\*/g,'');
    var num=function(v){
      var n=parseFloat(String(v==null?'':v).replace(/[^\d.\-]/g,''));
      return isFinite(n)?n:null;
    };
    var unesc=function(t){ return String(t==null?'':t).replace(/\\n/g,'\n').replace(/\\t/g,' ').trim(); };
    src.split('\n').forEach(function(ln0){
      var ln=ln0.replace(/\s*｜\s*/g,'|').trim();         // 全角 세로줄도 구분자로 친다
      if(ln.charAt(0)!=='@') return;
      var sp=ln.search(/[\s|]/);
      var head=(sp<0?ln.slice(1):ln.slice(1,sp)).replace(/:$/,'').toLowerCase();
      var rest=sp<0?'':ln.slice(sp+1).trim();
      var fields=rest.length?rest.split('|').map(function(x){ return x.trim(); }):[];
      var take=function(i){ return fields[i]==null?'':fields[i]; };
      var okNums=function(arr){ for(var i=0;i<arr.length;i++) if(arr[i]==null) return false; return true; };
      if(head==='done'||head==='end'||head==='say'||head==='완료'){ if(rest) say=rest; return; }
      if(head==='mv'||head==='move'){
        var x=num(take(1)), y=num(take(2));
        if(take(0)&&okNums([x,y])) ops.push({cmd:'mv',id:take(0),x:x,y:y}); else dropped++;
        return;
      }
      if(head==='sz'||head==='size'||head==='resize'||head==='rs'){
        var w=num(take(1)), h=num(take(2));
        if(take(0)&&okNums([w,h])) ops.push({cmd:'sz',id:take(0),w:w,h:h}); else dropped++;
        return;
      }
      if(head==='bx'||head==='box'||head==='rect'||head==='place'){
        var x2=num(take(1)), y2=num(take(2)), w2=num(take(3)), h2=num(take(4));
        if(take(0)&&okNums([x2,y2,w2,h2])) ops.push({cmd:'bx',id:take(0),x:x2,y:y2,w:w2,h:h2}); else dropped++;
        return;
      }
      if(head==='tx'||head==='text'||head==='set'||head==='put'){
        var i1=rest.indexOf('|');
        var id=i1<0?rest.trim():rest.slice(0,i1).trim();
        var body=i1<0?'':rest.slice(i1+1);                 // 텍스트 속 | 는 살린다
        if(id&&unesc(body)!=='') ops.push({cmd:'tx',id:id,text:unesc(body)}); else dropped++;
        return;
      }
      if(head==='add'||head==='new'){
        var cut=[], from=0;                                // 앞 다섯 칸(쪽·x·y·w·h) 뒤가 텍스트
        for(var k=0;k<5;k++){ var j2=rest.indexOf('|',from); if(j2<0) break; cut.push(rest.slice(from,j2).trim()); from=j2+1; }
        var body2=rest.slice(from);
        var pg=num(cut[0]), ax=num(cut[1]), ay=num(cut[2]), aw=num(cut[3]), ah=num(cut[4]);
        if(cut.length===5&&okNums([pg,ax,ay,aw,ah])&&unesc(body2)!=='')
          ops.push({cmd:'add',page:pg,x:ax,y:ay,w:aw,h:ah,text:unesc(body2)});
        else dropped++;
        return;
      }
      if(head==='del'||head==='rm'||head==='delete'||head==='remove'){
        var idd=take(0);
        if(idd) ops.push({cmd:'del',id:idd}); else dropped++;
        return;
      }
      dropped++;                                            // 모르는 @줄 — K
    });
    return {ops:ops,say:say,dropped:dropped};
  };
'''
EDIT_MOD = (EDIT_MOD
            .replace('OO가', OTTER + '이가')
            .replace('O~', OTTER + '~')
            .replace(' O 편집', ' ' + OTTER + ' 편집')
            .replace(' G ', ' ' + GIVE + ' ')
            .replace(' K ', ' ' + SKIP + ' ')
            .replace('·K 수', '·' + SKIP + ' 수')
            .replace('K 명령', SKIP + ' 명령')
            .replace('— K', '— ' + SKIP))

lines = s.split('\n')
pi = None
for i, l in enumerate(lines):
    if 'function parseChat(acc){' in l:
        pi = i
        break
assert pi is not None
close = None
for j in range(pi, pi + 20):
    if lines[j].strip() == '}':
        close = j
        break
assert close is not None
lines[close:close] = EDIT_MOD.split('\n')
s = '\n'.join(lines)

# 3) run() — 편집은 스냅샷을 싣는다
rep("    var txt=noteText(task==='outline'?scope:'doc');",
    "    // 14.24.0 · 편집(edit)은 노트 '글'이 아니라 문서 상태 스냅샷(상자 id·위치·크기)을 싣는다\n"
    "    var txt=(task==='edit')?aiSnapshot():noteText(task==='outline'?scope:'doc');")

# 4) 빈 편집 명령도 무시
rep("    if(task==='chat'&&!q) return;                     // 빈 질문 Enter — 조용히 무시",
    "    if(task==='chat'&&!q) return;                     // 빈 질문 Enter — 조용히 무시\n"
    "    if(task==='edit'&&!q) return;                     // 빈 편집 명령도 조용히 무시")

# 5) 스트림 중간 표시 — 편집은 설계도 진행만
rep("        acc+=d;\n        if(task==='chat'){",
    "        acc+=d;\n"
    "        if(task==='edit'){ out(editProgress(acc),true); return; } // @명령 줄은 완성 전엔 보여 주지 않는다\n"
    "        if(task==='chat'){")

# 6) 다 오면 편집 적용
rep("""          text=p.text; kind=p.kind;
        }
        lastText=text; lastKind=kind;""",
    """          text=p.text; kind=p.kind;
        }
        if(task==='edit'){ kind='edit'; text=editApplyDone(text); } // 다 오면 파싱→문서에 곧바로 반영
        lastText=text; lastKind=kind;""")

# 7) 실패 경로 두 곳 — 편집은 부분 명령을 말풍선에 남기지 않는다
rep("        lastText=acc?(task==='chat'?(parseChat(acc).text||''):acc):'';",
    "        lastText=(task==='edit')?'':(acc?(task==='chat'?(parseChat(acc).text||''):acc):'');")
rep("      lastText=acc?(task==='chat'?(parseChat(acc).text||''):acc):'';",
    "      lastText=(task==='edit')?'':(acc?(task==='chat'?(parseChat(acc).text||''):acc):'');")

# 8) sdyAiRun — ! 접두사면 편집 모드로
OT = OTTER
rep("""    if(qEl){ qEl.value=''; aiQGrow(); }                 // 본 질문은 말풍선(과 기록)에 남으니 창은 비운다
    run('chat',q);
  };""",
    """    var ec=editCmdOf(q);                                // ! 로 시작하면 문서 편집 모드
    if(qEl){ qEl.value=''; aiQGrow(); }                 // 본 질문은 말풍선(과 기록)에 남으니 창은 비운다
    if(ec!=null){
      if(!ec){ otterLine('! 뒤에 어떻게 고칠지 적어 줘 """ + OT + """~ · 예) !제목을 맨 위로 옮겨 줘'); return; }
      if(!inNote()){ otterLine('노트를 연 다음에 고쳐 달라고 해 줘 """ + OT + """~'); return; }
      if(!(window.__sdyAiBridge&&typeof window.__sdyAiBridge.apply==='function')){
        otterLine('문서 편집 준비가 안 됐어요 · 페이지를 새로고침해 주세요'); return;
      }
      run('edit',ec);
      return;
    }
    run('chat',q);
  };""")

# 9) aiQGrow — ! 를 치는 동안 검색창 편집 모드 표시
rep("""        say.style.setProperty('--ai-lift',lift+'px');
      }
    }catch(e){}""",
    """        say.style.setProperty('--ai-lift',lift+'px');
      }
      // 14.24.0 · 편집 접두사(!)를 치는 동안 검색창이 붓끝 색(편집 모드)으로 바뀐다
      try{
        var eOn=EDIT_PRE.test(q.value);
        var aBar=$('aiAsk'); if(aBar) aBar.classList.toggle('edit-on',!!eOn);
        var eTag=$('aiEditTag'); if(eTag) eTag.hidden=!eOn;
      }catch(e2){}
    }catch(e){}""")

io.open(p, 'w', encoding='utf-8').write(s)
print('frontend patched')
