// 엽스코드(Youpscord) — 앱 전체 공용 익명 채팅방.
//   텍스트 · 사진 · 파일 · 이모지(+반응) · 실시간 음성(WebRTC 시그널링 릴레이).
//
// 방은 영구 저장하지 않는다(인메모리): 마지막 대화 후 CHAT_TTL(24시간)이 지나면
// 메시지·파일이 '펑' 하고 사라진다. 닉네임은 라이브 새 이름 + 파스텔 색(라이브와 동일 팔레트).
import crypto from 'node:crypto';

const CHAT_TTL = parseInt(process.env.SDY_CHAT_TTL || '86400', 10); // 마지막 대화 후 이 시간 지나면 방 초기화(펑)
const MEMBER_TTL = 70;        // 핑 없이 이 시간 지나면 접속 종료로 간주
const MAX_MSGS = 200;         // 보관할 최근 메시지 수
const MAX_FILES = 120;        // 보관할 파일 수
const IMG_MAX = 8 * 1024 * 1024;
const FILE_MAX = 20 * 1024 * 1024;
const REACTIONS = ['👍', '❤️', '😂', '🔥', '😮', '🎉'];

// 라이브와 동일한 파스텔 팔레트 (닉네임 색 = 라이브 커서 색과 같은 톤)
const PASTELS = ['#f9a8d4', '#fda4af', '#fdba74', '#fcd34d', '#bef264', '#6ee7b7',
                 '#5eead4', '#7dd3fc', '#a5b4fc', '#c4b5fd', '#d8b4fe', '#f0abfc'];

const state = {
  members: new Map(),   // uid -> {uid,name,color,ts,voice,mute}
  msgs: [],             // {id,kind,uid,name,color,text?,file?,reactions?,ts}
  files: new Map(),     // fileId -> {buf,mime,name,size}
  bgm: null,            // {action,track,pos,ts} — 음성참가 배경음악(같이 듣기)
  lastAct: Date.now() / 1000,
  seq: 0,
};

const streams = new Map(); // uid -> Set<queue>

const nowSec = () => Date.now() / 1000;

function pickPastel() {
  const used = new Set();
  for (const m of state.members.values()) if (m.color) used.add(m.color);
  const free = PASTELS.filter((c) => !used.has(c));
  const pool = free.length ? free : PASTELS;
  return pool[Math.floor(Math.random() * pool.length)];
}

const publicMembers = () =>
  [...state.members.values()].map((m) => ({
    uid: m.uid, name: m.name, color: m.color, voice: !!m.voice, mute: !!m.mute,
  }));

function chatSend(uid, evt) {
  const set = streams.get(uid);
  if (!set) return;
  for (const q of set) { if (q.length >= 128) q.shift(); q.push(evt); }
}
function chatBroadcast(evt) {
  for (const set of streams.values()) {
    for (const q of set) { if (q.length >= 128) q.shift(); q.push(evt); }
  }
}
function chatPresence() {
  chatBroadcast({ type: 'presence', members: publicMembers(), ts: nowSec() });
}

function pushMsg(m) {
  state.seq += 1;
  m.id = state.seq;
  m.ts = nowSec();
  state.msgs.push(m);
  while (state.msgs.length > MAX_MSGS) state.msgs.shift();
  state.lastAct = nowSec();
  chatBroadcast({ type: 'msg', msg: m });
  return m;
}

function sanitizeName(s) {
  return String(s || '').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 24) || '익명 새';
}
function sanitizeText(s) {
  // eslint-disable-next-line no-control-regex
  return String(s || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, 2000);
}

let gcTimer = null;
function startGC() {
  if (gcTimer) return;
  gcTimer = setInterval(() => {
    const now = nowSec();
    // 1) 오래 핑 안 온 멤버 제거
    let removed = false;
    for (const [uid, m] of state.members) {
      if (now - m.ts > MEMBER_TTL) {
        state.members.delete(uid);
        removed = true;
        chatSend(uid, { type: 'bye' });
      }
    }
    if (removed) chatPresence();
    // 2) 대화 종료 후 TTL 지나면 '펑' — 메시지·파일만 날린다
    if (now - state.lastAct > CHAT_TTL && (state.msgs.length || state.files.size)) {
      state.msgs = [];
      state.files.clear();
      state.lastAct = now;
      chatBroadcast({ type: 'reset', ts: now });
    }
  }, parseInt(process.env.SDY_CHAT_GC_MS || '30000', 10));
  if (gcTimer.unref) gcTimer.unref();
}

export function registerChat(app) {
  startGC();

  // ── 입장 (닉네임 = 새 이름, 색 = 파스텔) ──
  app.post('/api/chat/join', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim().slice(0, 40);
    if (!uid) return reply.code(400).send({ ok: false, error: 'uid 필요' });
    const name = sanitizeName(d.name);
    let me = state.members.get(uid);
    if (!me) {
      me = { uid, name, color: pickPastel(), ts: nowSec(), voice: false, mute: false };
      state.members.set(uid, me);
      chatPresence();
    } else {
      if (me.name !== name) { me.name = name; chatPresence(); }
      me.ts = nowSec();
    }
    return reply.send({
      ok: true,
      me: { uid: me.uid, name: me.name, color: me.color },
      members: publicMembers(),
      msgs: state.msgs.slice(-80),
      ttl: CHAT_TTL,
      lastAct: state.lastAct,
      reactions: REACTIONS,
      bgm: state.bgm || null,
    });
  });

  app.post('/api/chat/ping', async (req, reply) => {
    const d = req.body || {};
    const me = state.members.get(String(d.uid || '').trim());
    if (me) me.ts = nowSec();
    return reply.send({ ok: true });
  });

  app.post('/api/chat/leave', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    if (state.members.delete(uid)) chatPresence();
    return reply.send({ ok: true });
  });

  // ── 메시지 ──
  app.post('/api/chat/msg', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    const text = sanitizeText(d.text);
    if (!text) return reply.code(400).send({ ok: false, error: '내용이 없습니다' });
    const msg = pushMsg({ kind: 'txt', uid, name: me.name, color: me.color, text, reactions: {} });
    return reply.send({ ok: true, msg });
  });

  // ── 사진/파일 업로드 ──
  app.post('/api/chat/upload', async (req, reply) => {
    let data;
    try { data = await req.file(); } catch { data = null; }
    if (!data) return reply.code(400).send({ ok: false, error: '파일 없음' });
    let uid = '';
    try { uid = String((data.fields && data.fields.uid && data.fields.uid.value) || '').trim(); } catch { uid = ''; }
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    let buf;
    try { buf = await data.toBuffer(); } catch { buf = null; }
    if (!buf || !buf.length) return reply.code(400).send({ ok: false, error: '빈 파일입니다' });
    const mime = String(data.mimetype || 'application/octet-stream').toLowerCase();
    const kind = mime.startsWith('image/') ? 'img' : 'file';
    const cap = kind === 'img' ? IMG_MAX : FILE_MAX;
    if (buf.length > cap) {
      return reply.code(400).send({
        ok: false,
        error: `${kind === 'img' ? '사진은' : '파일은'} ${Math.round(cap / 1048576)}MB 이하만 가능해요`,
      });
    }
    const fileId = crypto.randomBytes(8).toString('hex');
    const fname = String(data.filename || (kind === 'img' ? 'image.jpg' : 'file')).slice(0, 120);
    state.files.set(fileId, { buf, mime, name: fname, size: buf.length });
    while (state.files.size > MAX_FILES) {
      const k = state.files.keys().next().value;
      state.files.delete(k);
    }
    const msg = pushMsg({
      kind, uid, name: me.name, color: me.color,
      file: { id: fileId, name: fname, size: buf.length, mime }, reactions: {},
    });
    return reply.send({ ok: true, msg });
  });

  // ── 파일 내려받기/이미지 표시 ──
  app.get('/api/chat/file/:id', async (req, reply) => {
    const f = state.files.get(String(req.params.id || ''));
    if (!f) return reply.code(404).send({ error: '파일이 사라졌어요 (방이 펑 했거나 오래된 파일)' });
    reply.header('Cache-Control', 'no-store');
    reply.header('Content-Type', f.mime);
    reply.header('Content-Length', f.size);
    const inline = f.mime.startsWith('image/');
    reply.header('Content-Disposition',
      inline ? 'inline' : `attachment; filename*=UTF-8''${encodeURIComponent(f.name)}`);
    return reply.send(f.buf);
  });

  // ── 이모지 반응 ──
  app.post('/api/chat/react', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    const id = parseInt(d.id, 10);
    const emoji = String(d.emoji || '');
    if (!REACTIONS.includes(emoji)) return reply.code(400).send({ ok: false, error: '지원하지 않는 이모지' });
    const msg = state.msgs.find((m) => m.id === id);
    if (!msg) return reply.code(404).send({ ok: false, error: '메시지가 없습니다' });
    msg.reactions = msg.reactions || {};
    const list = msg.reactions[emoji] || (msg.reactions[emoji] = []);
    const i = list.indexOf(uid);
    if (i >= 0) list.splice(i, 1); else list.push(uid);
    if (!list.length) delete msg.reactions[emoji];
    state.lastAct = nowSec();
    chatBroadcast({ type: 'react', id, reactions: msg.reactions });
    return reply.send({ ok: true });
  });

  // ── 메시지 삭제 (본인 메시지만) ──
  app.post('/api/chat/del', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    const id = parseInt(d.id, 10);
    const i = state.msgs.findIndex((m) => m.id === id);
    if (i < 0) return reply.code(404).send({ ok: false, error: '메시지가 없습니다' });
    const msg = state.msgs[i];
    if (msg.uid !== uid) return reply.code(403).send({ ok: false, error: '내 메시지만 지울 수 있어요' });
    state.msgs.splice(i, 1);
    if (msg.file && msg.file.id) state.files.delete(msg.file.id);
    state.lastAct = nowSec();
    chatBroadcast({ type: 'del', id });
    return reply.send({ ok: true });
  });

  // ── 음성참가 배경음악(같이 듣기) — 재생 상태를 방 전체에 동기화 ──
  app.post('/api/chat/bgm', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    const action = String(d.action || 'play');
    if (!['play', 'pause', 'stop'].includes(action)) {
      return reply.code(400).send({ ok: false, error: '잘못된 동작입니다' });
    }
    let track = null;
    if (action !== 'stop') {
      const t = (d.track && typeof d.track === 'object') ? d.track : {};
      track = {
        id: String(t.id || '').slice(0, 80),
        title: String(t.title || '').slice(0, 120),
        artist: String(t.artist || '').slice(0, 120),
      };
      if (!track.id) return reply.code(400).send({ ok: false, error: '곡이 없습니다' });
    }
    const evt = {
      type: 'bgm', from: { uid, name: me.name, color: me.color },
      action, track, pos: Math.max(0, parseFloat(d.pos) || 0), ts: nowSec(),
    };
    state.bgm = action === 'stop' ? null : { action, track, pos: evt.pos, ts: evt.ts };
    chatBroadcast(evt);
    return reply.send({ ok: true });
  });

  // ── 노크 (접속 중인 모두에게 알림) ──
  app.post('/api/chat/knock', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    chatBroadcast({ type: 'knock', from: { uid, name: me.name, color: me.color }, ts: nowSec() });
    return reply.send({ ok: true });
  });

  // ── WebRTC ICE 설정 (STUN 다중 + TURN 환경변수) ──
  app.get('/api/chat/config', async (req, reply) => {
    // STUN 은 '공인 IP 확인'만 도와준다. 방화벽·대칭 NAT·통신사(CGNAT) 뒤에서는
    // STUN 으로는 P2P 가 맺어지지 않아 '연결 중'에서 멈춘다 → TURN 이 필수.
    const iceServers = [
      { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
      { urls: ['stun:stun.cloudflare.com:3478'] },
    ];
    const turn = (process.env.SDY_TURN_URL || '').trim();
    if (turn) {
      iceServers.push({
        urls: turn.split(',').map((s) => s.trim()).filter(Boolean),
        username: process.env.SDY_TURN_USER || '',
        credential: process.env.SDY_TURN_PASS || '',
      });
    }
    return reply.send({ ok: true, ice: { iceServers } });
  });

  // ── 음성 상태 ──
  app.post('/api/chat/voice', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const me = state.members.get(uid);
    if (!me) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    me.voice = !!d.on;
    me.mute = !!d.mute;
    me.ts = nowSec();
    chatPresence();
    return reply.send({ ok: true, members: publicMembers() });
  });

  // ── WebRTC 시그널링 릴레이 (peer → peer) ──
  app.post('/api/chat/signal', async (req, reply) => {
    const d = req.body || {};
    const uid = String(d.uid || '').trim();
    const to = String(d.to || '').trim();
    if (!state.members.has(uid)) return reply.code(400).send({ ok: false, error: '먼저 입장해 주세요' });
    if (!state.members.has(to)) return reply.code(404).send({ ok: false, error: '상대가 없습니다' });
    chatSend(to, { type: 'signal', from: uid, kind: String(d.kind || ''), payload: d.payload || null });
    return reply.send({ ok: true });
  });

  // ── SSE 스트림 (uid 별 큐 — 시그널링은 상대에게만 간다) ──
  app.get('/api/chat/stream', async (req, reply) => {
    const uid = String(req.query.uid || '').trim().slice(0, 40);
    if (!uid) return reply.code(400).send({ ok: false, error: 'uid 필요' });
    const queue = [];
    if (!streams.has(uid)) streams.set(uid, new Set());
    streams.get(uid).add(queue);
    reply.raw.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    const send = (payload) => {
      try { reply.raw.write(`event: yp\ndata: ${JSON.stringify(payload)}\n\n`); } catch { /* closed */ }
    };
    send({ type: 'hello', ts: nowSec() });
    let lastSent = Date.now();
    const timer = setInterval(() => {
      try {
        let flushed = false;
        while (queue.length) { send(queue.shift()); flushed = true; }
        if (!flushed && Date.now() - lastSent >= 20000) reply.raw.write(': keep-alive\n\n');
        lastSent = Date.now();
      } catch { clearInterval(timer); }
    }, 1000);
    req.raw.on('close', () => {
      clearInterval(timer);
      const set = streams.get(uid);
      if (set) { set.delete(queue); if (!set.size) streams.delete(uid); }
    });
  });
}
